1.Copy the file


2.Go to \Users\(Computer user name)\AppData\Roaming\.minecraft\saves


3.Paste the file into the saves file


4.This map is for 1.8 and 1.9